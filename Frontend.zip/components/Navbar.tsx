/**
- FILE: components/Navbar.tsx
- PURPOSE:
-   Full-width sticky top navigation bar (`<header className="w-full ...">`).
-   Renders the Jalurtumbuh Jobs brand identity (landscape logo image), role-aware
-   navigation links, user profile pill, logout button, and a responsive mobile navigation
-   strip for smaller viewports.
 */

'use client';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Briefcase, LogOut, UserCircle } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { roleLabel } from '@/lib/format';

export default function Navbar() {
  const { user, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  let links: [string, string][] = [['/', 'Lowongan']];
  if (user?.role === 'candidate') {
    links = [
      ['/', 'Lowongan'],
      ['/applications', 'Lamaran Saya'],
    ];
  } else if (user?.role === 'company' || user?.role === 'admin') {
    links = [
      ['/dashboard', 'Kelola Rekrutmen'],
      ['/dashboard/companies', 'Cari Perusahaan'],
      ['/', 'Portal Publik'],
    ];
  } else if (user?.role === 'super_admin') {
    links = [
      ['/superadmin', 'Ringkasan'],
      ['/superadmin/users', 'Kelola User'],
      ['/dashboard', 'Rekrutmen'],
      ['/dashboard/companies', 'Perusahaan'],
    ];
  }

  return (
    <header className="sticky top-0 z-30 w-full border-b border-slate-200/80 bg-white/95 backdrop-blur">
      <div className="flex w-full items-center justify-between px-4 py-3 sm:px-6 lg:px-10">
        {/* Left: Logo + Desktop Links */}
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center">
            <Image
              src="/images/Logo Jalur Tumbuh.jpeg"
              alt="Logo Jalurtumbuh"
              width={180}
              height={40}
              className="h-9 w-auto object-contain sm:h-10"
              priority
            />
          </Link>

          <nav className="hidden items-center gap-1 md:flex">
            {links.map(([href, label]) => {
              const active = pathname === href;
              return (
                <Link
                  key={href}
                  href={href}
                  className={`rounded-lg px-3.5 py-2 text-sm font-medium transition ${
                    active
                      ? 'bg-brand-light font-semibold text-brand-blue'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-brand-blue'
                  }`}
                >
                  {label}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Right: User Session / Auth Actions */}
        <div className="flex items-center gap-2.5">
          {user ? (
            <>
              <div className="hidden items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs sm:flex">
                <UserCircle className="h-4 w-4 text-brand-blue" />
                <span className="font-semibold text-slate-800">{user.name}</span>
                <span className="rounded-full bg-brand-light px-2 py-0.5 font-medium text-brand-blue">
                  {roleLabel[user.role] ?? user.role}
                </span>
              </div>
              <button
                className="btn-outline px-3 py-1.5 text-xs"
                onClick={() => {
                  logout();
                  router.push('/login');
                }}
              >
                <LogOut className="mr-1.5 h-3.5 w-3.5" /> Keluar
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="btn-outline">
                Masuk
              </Link>
              <Link href="/register" className="btn">
                <Briefcase className="mr-1.5 h-4 w-4" /> Daftar
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Responsive Mobile Navigation Strip */}
      <div className="flex gap-2 overflow-x-auto border-t border-slate-100 px-4 py-2 md:hidden">
        {links.map(([href, label]) => (
          <Link
            key={href}
            href={href}
            className={`whitespace-nowrap rounded-lg px-3 py-1 text-xs font-medium ${
              pathname === href ? 'bg-brand-light font-semibold text-brand-blue' : 'text-slate-600'
            }`}
          >
            {label}
          </Link>
        ))}
      </div>
    </header>
  );
}